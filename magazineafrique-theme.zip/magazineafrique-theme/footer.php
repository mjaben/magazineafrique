<?php
/**
 * Magazine Afrique — Footer Template
 * Minimalist Editorial Architecture with Vintage Bottom Mobile Bar
 *
 * @package MagazineAfrique
 */
?>

<div class="divider-africa container-editorial">
    <span class="divider-africa-icon">❖</span>
</div>

<?php
// Bottom Ad Slot (Slot 1801863291 - Above Footer)
if (function_exists('magazineafrique_render_ad_bottom')) {
    magazineafrique_render_ad_bottom();
}
?>

<footer class="site-footer">
    <div class="container-editorial">
        <div class="footer-inner-grid">
            
            <!-- Column 1: Brand Info -->
            <div class="footer-col" style="max-width: 340px;">
                <div class="footer-brand-wrap" style="margin-bottom: 0.75rem;">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/logo-dark.png'); ?>" alt="Magazine Afrique" class="footer-logo-img" height="40" style="object-fit: contain;" />
                </div>
                <p style="font-size: 0.8125rem; color: #C7BFB3; line-height: 1.6; margin-bottom: 1rem;">
                    Independent pan-African journal of strategic analysis, economics, politics, diplomacy, and culture.
                </p>
                
                <!-- Footer Multi-Lingual Switcher -->
                <div class="footer-lang-selector" style="margin-bottom: 1rem; display: flex; align-items: center; gap: 0.4rem; font-size: 0.75rem; color: #9E968B;">
                    <span>Edition:</span>
                    <button type="button" class="lang-chip-footer active" onclick="window.magazineafriqueSwitchLanguage('en')">EN</button>
                    <span>·</span>
                    <button type="button" class="lang-chip-footer" onclick="window.magazineafriqueSwitchLanguage('fr')">FR</button>
                    <span>·</span>
                    <button type="button" class="lang-chip-footer" onclick="window.magazineafriqueSwitchLanguage('ar')">AR</button>
                    <span>·</span>
                    <button type="button" class="lang-chip-footer" onclick="window.magazineafriqueSwitchLanguage('pt')">PT</button>
                    <span>·</span>
                    <button type="button" class="lang-chip-footer" onclick="window.magazineafriqueSwitchLanguage('sw')">SW</button>
                </div>

                <div style="display: flex; gap: 1rem; font-size: 0.875rem; color: #D1C9BE;">
                    <a href="https://twitter.com" target="_blank" rel="noopener">𝕏</a>
                    <a href="https://linkedin.com" target="_blank" rel="noopener">LinkedIn</a>
                    <a href="https://facebook.com" target="_blank" rel="noopener">Facebook</a>
                </div>
            </div>

            <!-- Column 2: Key Sections -->
            <div class="footer-col">
                <h4>Sections</h4>
                <ul>
                    <?php
                    $categories = get_categories(array('number' => 6, 'hide_empty' => false, 'exclude' => array(1)));
                    foreach ($categories as $cat) {
                        if (strtolower($cat->slug) === 'uncategorized') continue;
                        echo '<li><a href="' . esc_url(get_category_link($cat->term_id)) . '">' . esc_html($cat->name) . '</a></li>';
                    }
                    ?>
                </ul>
            </div>

            <!-- Column 3: Membership & Reader Portal -->
            <div class="footer-col">
                <h4>Club &amp; Readers</h4>
                <ul>
                    <li><a href="<?php echo esc_url(home_url('/subscribe/')); ?>">Club Prestige Membership</a></li>
                    <li><a href="<?php echo esc_url(home_url('/profile/')); ?>">Reader Profile &amp; Following Wire</a></li>
                    <li><a href="<?php echo esc_url(home_url('/notifications/')); ?>">Breaking News Alerts</a></li>
                    <li><a href="<?php echo esc_url(home_url('/newsletter/')); ?>">The Africa Brief Newsletter</a></li>
                    <li><a href="<?php echo esc_url(home_url('/contact/')); ?>">Contact Editorial Desk</a></li>
                    <li><a href="javascript:void(0)" class="btn-install-app" style="color: #F59E0B; font-weight: 700;">📲 Install Gazette App (PWA)</a></li>
                </ul>
            </div>

            <!-- Column 4: Newsletter -->
            <div class="footer-col" style="max-width: 300px;">
                <h4>The Africa Brief</h4>
                <p style="font-size: 0.75rem; color: #C7BFB3; margin-bottom: 0.75rem; line-height: 1.5;">
                    Essential continental intelligence, delivered every Thursday morning.
                </p>
                <form class="magazine-newsletter-form" style="display: flex; flex-direction: column; gap: 0.5rem;">
                    <input type="email" name="email" placeholder="Your work email" required style="padding: 0.6rem 0.75rem; border-radius: 0.25rem; border: 1px solid rgba(255,255,255,0.15); background: rgba(255,255,255,0.06); font-size: 0.75rem; color: #FAF7F2; outline: none;" />
                    <button type="submit" style="background-color: #0B5128; color: #FAF7F2; font-weight: 700; border: 1px solid #0E6834; padding: 0.55rem; border-radius: 0.25rem; font-size: 0.75rem; cursor: pointer;">
                        Subscribe
                    </button>
                    <div class="newsletter-feedback"></div>
                </form>
            </div>

        </div>

        <!-- Bottom Copyright & Legal -->
        <div class="footer-bottom-row">
            <div>
                &copy; <?php echo esc_html(date('Y')); ?> Magazine Afrique. All rights reserved.
            </div>
            <div style="display: flex; align-items: center; gap: 1.25rem; flex-wrap: wrap;">
                <a href="<?php echo esc_url(home_url('/legal-notice/')); ?>">Legal Notice</a>
                <a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>">Privacy</a>
                <a href="<?php echo esc_url(home_url('/terms/')); ?>">Terms</a>
                <a href="<?php echo esc_url(home_url('/contact/')); ?>">Contact</a>
                <a href="javascript:void(0)" onclick="window.magazineafriquePurgeCacheAndReload &amp;&amp; window.magazineafriquePurgeCacheAndReload()" class="footer-cache-reload-link" title="Purge local cache and load newest edition">↻ Reload Edition</a>
            </div>
        </div>
    </div>
</footer>

<!-- Vintage Broadsheet Bottom Mobile Navigation (With Smart Scroll Behavior) -->
<nav class="vintage-bottom-nav" id="vintage-mobile-nav" aria-label="Mobile Navigation">
    <a href="<?php echo esc_url(home_url('/')); ?>" class="vintage-nav-item <?php echo is_front_page() ? 'active' : ''; ?>">
        <svg class="vintage-nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
            <path d="M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-2 2Zm0 0a2 2 0 0 1-2-2v-9c0-1.1.9-2 2-2h2"/>
            <path d="M18 14h-8"/>
            <path d="M15 18h-5"/>
            <path d="M10 6h8v4h-8V6Z"/>
        </svg>
        <span class="vintage-nav-label">Gazette</span>
    </a>

    <button type="button" id="bottom-menu-toggle" class="vintage-nav-item" aria-label="Open Sections Menu">
        <svg class="vintage-nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
            <line x1="3" y1="6" x2="21" y2="6"/>
            <line x1="3" y1="12" x2="21" y2="12"/>
            <line x1="3" y1="18" x2="21" y2="18"/>
        </svg>
        <span class="vintage-nav-label">Sections</span>
    </button>

    <button type="button" id="bottom-search-toggle" class="vintage-nav-item" aria-label="Open Search">
        <svg class="vintage-nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="11" cy="11" r="8"/>
            <line x1="21" y1="21" x2="16.65" y2="16.65"/>
        </svg>
        <span class="vintage-nav-label">Search</span>
    </button>

    <a href="<?php echo esc_url(home_url('/subscribe/')); ?>" class="vintage-nav-item <?php echo is_page('subscribe') ? 'active' : ''; ?>">
        <svg class="vintage-nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
        </svg>
        <span class="vintage-nav-label">Prestige</span>
    </a>

    <a href="<?php echo esc_url(home_url('/profile/')); ?>" class="vintage-nav-item <?php echo is_page('profile') ? 'active' : ''; ?>">
        <svg class="vintage-nav-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
            <circle cx="12" cy="7" r="4"/>
        </svg>
        <span class="vintage-nav-label">Profile</span>
    </a>
</nav>

<!-- Strategic Slide-In Pill for WhatsApp Official Channel (14-day capped, 65% scroll trigger) -->
<div id="magafrique-wa-slidein" class="magafrique-wa-slidein" style="display:none;" aria-live="polite">
    <div class="magafrique-wa-content">
        <span class="magafrique-wa-icon">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
            </svg>
        </span>
        <div class="magafrique-wa-text">
            <strong>Pan-African Wire on WhatsApp</strong>
            <span>Direct breaking intelligence briefs.</span>
        </div>
        <a href="https://whatsapp.com/channel/0029VbABUTT23n3fleq5C91h" target="_blank" rel="noopener" class="magafrique-wa-action-btn" id="magafrique-wa-join-btn">
            Follow Wire ↗
        </a>
        <button type="button" class="magafrique-wa-close-btn" id="magafrique-wa-close-btn" aria-label="Dismiss">✕</button>
    </div>
</div>

<?php wp_footer(); ?>
</body>
</html>
